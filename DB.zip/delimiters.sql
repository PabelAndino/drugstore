

DELIMITER //
CREATE TRIGGER trUpdateStockIngreso AFTER INSERT ON
detalle_ingreso
 FOR EACH ROW BEGIN
 UPDATE articulo SET stock = stock + NEW.cantidad
 WHERE articulo.idarticulo = NEW.idarticulo ;
END
//
DELIMITER ;




 DELIMITER //
 
CREATE TRIGGER trUpdateStockVenta AFTER INSERT ON
detalle_venta
 
 FOR EACH ROW BEGIN
 UPDATE articulo SET stock = stock - NEW.cantidad
 WHERE articulo.idarticulo = NEW.idarticulo;
 END
 //
 
 DELIMITER ;



 DELIMITER //
 
CREATE TRIGGER trUpdateStockVentaEliminada AFTER UPDATE ON
detalle_venta
 
 FOR EACH ROW BEGIN
 UPDATE articulo SET stock = stock + NEW.cantidad
 WHERE articulo.idarticulo = NEW.idarticulo;
 END
 //
 
 DELIMITER ;


DELIMITER //

CREATE TRIGGER trUpdateStockVentaEliminadaDetalle AFTER UPDATE ON
venta
 
 FOR EACH ROW BEGIN
 IF NEW.estado='Anulado'
 THEN 

 UPDATE detalle_venta SET estado = 'Anulado'
 WHERE detalle_venta.idventa = NEW.idventa;
 END IF;
 END

 //
 
 DELIMITER ;




DELIMITER //

CREATE TRIGGER trUpdateStockIngresoEliminadaDetalle AFTER UPDATE ON
ingreso
 
 FOR EACH ROW BEGIN
 IF NEW.estado='Anulado'
 THEN 

 UPDATE detalle_ingreso SET estado = 'Anulado'
 WHERE detalle_ingreso.idingreso = NEW.idingreso;
 END IF;
 END


 //
 
DELIMITER //
 
CREATE TRIGGER trUpdateStockIngresoEliminada AFTER UPDATE ON
detalle_ingreso
 
 FOR EACH ROW BEGIN
 IF NEW.estado='Anulado'
 THEN 
 UPDATE articulo SET stock = stock - NEW.cantidad
 WHERE articulo.idarticulo = NEW.idarticulo;
  END IF;



 END
 //
 
 DELIMITER ;